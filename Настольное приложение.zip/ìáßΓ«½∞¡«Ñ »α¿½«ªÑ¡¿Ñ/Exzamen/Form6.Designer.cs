﻿namespace Exzamen
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            this.button5 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this._Сеть_фитнес_клубов__F_I_T_DataSet = new Exzamen._Сеть_фитнес_клубов__F_I_T_DataSet();
            this.квитанцияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.квитанцияTableAdapter = new Exzamen._Сеть_фитнес_клубов__F_I_T_DataSetTableAdapters.КвитанцияTableAdapter();
            this.кодКвитанцииDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.услугаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.времяПосещенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаПосещенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.стоимостьDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._Сеть_фитнес_клубов__F_I_T_DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.квитанцияBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Violet;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button5.Location = new System.Drawing.Point(805, 592);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(117, 50);
            this.button5.TabIndex = 14;
            this.button5.Text = "Назад";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(389, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 37);
            this.label2.TabIndex = 13;
            this.label2.Text = "Квитанции";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодКвитанцииDataGridViewTextBoxColumn,
            this.клиентDataGridViewTextBoxColumn,
            this.услугаDataGridViewTextBoxColumn,
            this.времяПосещенияDataGridViewTextBoxColumn,
            this.датаПосещенияDataGridViewTextBoxColumn,
            this.стоимостьDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.квитанцияBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 94);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(910, 492);
            this.dataGridView1.TabIndex = 15;
            // 
            // _Сеть_фитнес_клубов__F_I_T_DataSet
            // 
            this._Сеть_фитнес_клубов__F_I_T_DataSet.DataSetName = "_Сеть_фитнес_клубов__F_I_T_DataSet";
            this._Сеть_фитнес_клубов__F_I_T_DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // квитанцияBindingSource
            // 
            this.квитанцияBindingSource.DataMember = "Квитанция";
            this.квитанцияBindingSource.DataSource = this._Сеть_фитнес_клубов__F_I_T_DataSet;
            // 
            // квитанцияTableAdapter
            // 
            this.квитанцияTableAdapter.ClearBeforeFill = true;
            // 
            // кодКвитанцииDataGridViewTextBoxColumn
            // 
            this.кодКвитанцииDataGridViewTextBoxColumn.DataPropertyName = "Код квитанции";
            this.кодКвитанцииDataGridViewTextBoxColumn.HeaderText = "Код квитанции";
            this.кодКвитанцииDataGridViewTextBoxColumn.Name = "кодКвитанцииDataGridViewTextBoxColumn";
            // 
            // клиентDataGridViewTextBoxColumn
            // 
            this.клиентDataGridViewTextBoxColumn.DataPropertyName = "Клиент";
            this.клиентDataGridViewTextBoxColumn.HeaderText = "Клиент";
            this.клиентDataGridViewTextBoxColumn.Name = "клиентDataGridViewTextBoxColumn";
            // 
            // услугаDataGridViewTextBoxColumn
            // 
            this.услугаDataGridViewTextBoxColumn.DataPropertyName = "Услуга";
            this.услугаDataGridViewTextBoxColumn.HeaderText = "Услуга";
            this.услугаDataGridViewTextBoxColumn.Name = "услугаDataGridViewTextBoxColumn";
            // 
            // времяПосещенияDataGridViewTextBoxColumn
            // 
            this.времяПосещенияDataGridViewTextBoxColumn.DataPropertyName = "Время посещения";
            this.времяПосещенияDataGridViewTextBoxColumn.HeaderText = "Время посещения";
            this.времяПосещенияDataGridViewTextBoxColumn.Name = "времяПосещенияDataGridViewTextBoxColumn";
            // 
            // датаПосещенияDataGridViewTextBoxColumn
            // 
            this.датаПосещенияDataGridViewTextBoxColumn.DataPropertyName = "Дата посещения";
            this.датаПосещенияDataGridViewTextBoxColumn.HeaderText = "Дата посещения";
            this.датаПосещенияDataGridViewTextBoxColumn.Name = "датаПосещенияDataGridViewTextBoxColumn";
            // 
            // стоимостьDataGridViewTextBoxColumn
            // 
            this.стоимостьDataGridViewTextBoxColumn.DataPropertyName = "Стоимость";
            this.стоимостьDataGridViewTextBoxColumn.HeaderText = "Стоимость";
            this.стоимостьDataGridViewTextBoxColumn.Name = "стоимостьDataGridViewTextBoxColumn";
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 654);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._Сеть_фитнес_клубов__F_I_T_DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.квитанцияBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private _Сеть_фитнес_клубов__F_I_T_DataSet _Сеть_фитнес_клубов__F_I_T_DataSet;
        private System.Windows.Forms.BindingSource квитанцияBindingSource;
        private _Сеть_фитнес_клубов__F_I_T_DataSetTableAdapters.КвитанцияTableAdapter квитанцияTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодКвитанцииDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn клиентDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn услугаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn времяПосещенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаПосещенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn стоимостьDataGridViewTextBoxColumn;
    }
}
﻿namespace Exzamen
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.button5 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this._Сеть_фитнес_клубов__F_I_T_DataSet = new Exzamen._Сеть_фитнес_клубов__F_I_T_DataSet();
            this.отделенияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.отделенияTableAdapter = new Exzamen._Сеть_фитнес_клубов__F_I_T_DataSetTableAdapters.ОтделенияTableAdapter();
            this.кодОтделенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеОтделенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._Сеть_фитнес_клубов__F_I_T_DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.отделенияBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Violet;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button5.Location = new System.Drawing.Point(808, 595);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(117, 50);
            this.button5.TabIndex = 16;
            this.button5.Text = "Назад";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(387, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 37);
            this.label2.TabIndex = 15;
            this.label2.Text = "Отделения";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодОтделенияDataGridViewTextBoxColumn,
            this.названиеОтделенияDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.отделенияBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 103);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(910, 486);
            this.dataGridView1.TabIndex = 17;
            // 
            // _Сеть_фитнес_клубов__F_I_T_DataSet
            // 
            this._Сеть_фитнес_клубов__F_I_T_DataSet.DataSetName = "_Сеть_фитнес_клубов__F_I_T_DataSet";
            this._Сеть_фитнес_клубов__F_I_T_DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // отделенияBindingSource
            // 
            this.отделенияBindingSource.DataMember = "Отделения";
            this.отделенияBindingSource.DataSource = this._Сеть_фитнес_клубов__F_I_T_DataSet;
            // 
            // отделенияTableAdapter
            // 
            this.отделенияTableAdapter.ClearBeforeFill = true;
            // 
            // кодОтделенияDataGridViewTextBoxColumn
            // 
            this.кодОтделенияDataGridViewTextBoxColumn.DataPropertyName = "Код отделения";
            this.кодОтделенияDataGridViewTextBoxColumn.HeaderText = "Код отделения";
            this.кодОтделенияDataGridViewTextBoxColumn.Name = "кодОтделенияDataGridViewTextBoxColumn";
            // 
            // названиеОтделенияDataGridViewTextBoxColumn
            // 
            this.названиеОтделенияDataGridViewTextBoxColumn.DataPropertyName = "Название отделения";
            this.названиеОтделенияDataGridViewTextBoxColumn.HeaderText = "Название отделения";
            this.названиеОтделенияDataGridViewTextBoxColumn.Name = "названиеОтделенияDataGridViewTextBoxColumn";
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 654);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form7";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form7_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._Сеть_фитнес_клубов__F_I_T_DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.отделенияBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private _Сеть_фитнес_клубов__F_I_T_DataSet _Сеть_фитнес_клубов__F_I_T_DataSet;
        private System.Windows.Forms.BindingSource отделенияBindingSource;
        private _Сеть_фитнес_клубов__F_I_T_DataSetTableAdapters.ОтделенияTableAdapter отделенияTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодОтделенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеОтделенияDataGridViewTextBoxColumn;
    }
}